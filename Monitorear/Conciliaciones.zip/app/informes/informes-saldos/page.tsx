import React from 'react';

const InformesSaldosPage: React.FC = () => {
    return (
        <div>
            <h1>Informes Saldos</h1>
            <p>Bienvenido a la página de Informes Saldos.</p>
        </div>
    );
};

export default InformesSaldosPage;