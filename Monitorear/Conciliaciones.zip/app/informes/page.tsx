'use client';
import MenuInformes from "@/components/ui/menu/menu-informes";

export default function Page() {
  return (
    <div>
      <MenuInformes />
    </div>
  )
}