'use client'
import React from 'react';
// import DemoPage from '@/components/pruebas/demo-page';

const ExampleTable = () => {

  return (
    <h1>HOLA MUNDO!!!</h1>
  );
};

export default ExampleTable;
